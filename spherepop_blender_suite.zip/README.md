# Spherepop Blender Experiments

This package contains Blender Python (`bpy`) demonstrations of Spherepop semantics.

The design rule is that `SPWorld` is authoritative. Blender geometry is only a rendering of the event history.

## Included scenes

`01_pop_field.py` demonstrates persistent introduction of distinctions.

`02_bind_lattice.py` demonstrates first-class relations and then binds bindings themselves.

`03_refuse_frontier.py` demonstrates refusal as removal from the active frontier without erasing historical existence.

## Running

From the repository root:

```bash
blender --python scenes/01_pop_field.py
```

or:

```bash
blender --background --python scenes/02_bind_lattice.py --render-anim
```

For interactive use, open Blender's scripting workspace and run any scene script.

## Next layers

The intended continuation is:

```text
04_collapse_representation.py
05_history_frontier.py
06_nested_continuations.py
07_repair_cycle.py
08_observer_dependent_collapse.py
09_recursive_city.py
10_spherepop_cosmology.py
```

The later simulations should preserve the same separation between semantic history and Blender representation.
