from __future__ import annotations

import math
import random
import sys
from pathlib import Path

import bpy

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from spherepop_blender.core import SPWorld, pop
from spherepop_blender.blender import (
    add_camera,
    add_ground,
    add_world_light,
    animate_scale_in,
    create_event_sphere,
    make_material,
    reset_scene,
    set_render_defaults,
)


def main() -> None:
    reset_scene()
    set_render_defaults(frame_end=220)

    world = SPWorld()
    rng = random.Random(7)

    active_mat = make_material(
        "PopActive",
        base=(0.15, 0.35, 0.95, 1.0),
        emission=(0.1, 0.25, 1.0, 1.0),
        emission_strength=1.8,
    )

    add_ground()
    add_world_light()
    add_camera(location=(0, -16, 9), target=(0, 0, 1))

    for i in range(18):
        frame = 10 + i * 10
        angle = i * 0.9
        radius = 1.4 + 0.22 * i
        z = -0.2 + 0.28 * i

        x = math.cos(angle) * radius + rng.uniform(-0.35, 0.35)
        y = math.sin(angle) * radius + rng.uniform(-0.35, 0.35)

        eid = pop(
            world,
            {
                "label": f"d{i}",
                "creation_order": i,
            },
            frame=frame,
        )
        event = world.events[eid]

        obj = create_event_sphere(
            event,
            (x, y, z),
            radius=0.40,
            material=active_mat,
        )
        animate_scale_in(
            obj,
            start_frame=frame,
            duration=8,
        )

    bpy.context.scene["spherepop_event_count"] = len(world.events)
    bpy.context.scene["spherepop_principle"] = "Pop introduces persistent distinctions"


if __name__ == "__main__":
    main()
